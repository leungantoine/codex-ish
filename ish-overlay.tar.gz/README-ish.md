# OpenAI Codex CLI 0.158.0 for iSH-AOK ARM64 Alpine

Built from the official `rust-v0.158.0` tag for `aarch64-unknown-linux-musl`. This build treats `PR_SET_PDEATHSIG` returning `EINVAL` as unsupported, skipping the parent-PID guard only in that case. Tokio probes `waitid(P_PIDFD)` and uses its SIGCHLD reaper when iSH rejects that call. Normal Linux behavior is retained when the calls work.

## Install on the iPad

Select iSH-AOK's ARM64 Alpine root and install directly from the repository's latest verified Release:

```sh
uname -m     # must say aarch64
apk add ca-certificates curl tar coreutils git bash
update-ca-certificates
curl -fL https://raw.githubusercontent.com/leungantoine/codex-ish/main/install.sh -o install-codex-ish.sh
sh install-codex-ish.sh
export PATH="$HOME/.local/bin:$PATH"
codex --version
```

The installer verifies the Release archive's SHA-256 checksum and keeps the companion executables beside `codex`. The archive also includes static ARM64 musl `rg` under `codex-path/`. Put the `export PATH=...` line in `~/.profile` (`~/.bashrc` if using bash) for future sessions. The repository README has full maintenance and troubleshooting instructions.

## Authenticate and test shell execution

```sh
codex login --device-auth
mkdir -p "$HOME/codex-test" && cd "$HOME/codex-test"
codex --sandbox danger-full-access --ask-for-approval on-request
```

Ask Codex: `Run printf 'ish-shell-ok\n' with the local shell and show the output.` It should show `ish-shell-ok` and exit 0. For a noninteractive test after login:

```sh
codex exec --sandbox danger-full-access --ask-for-approval never \
  --skip-git-repo-check \
  "Use the local shell to run printf 'ish-shell-ok\\n', then report its exact output."
```

**Security:** iSH lacks the Linux kernel sandbox that Codex normally uses. `danger-full-access` allows Codex-run commands to access all files available inside this iSH root and the network. `--ask-for-approval never` also skips prompts; use it only for the small test above. The archive deliberately omits `bwrap`. Use a dedicated root without sensitive files if possible.

The optional `diagnostics/ish-syscall-probe` reports `PR_SET_PDEATHSIG`, `pidfd_open`, `waitid(P_PIDFD)`, and `waitpid` behavior on the iPad. It uses no network or credentials.

The GitHub Actions workflow checks binary architecture, static linkage, checksums, CLI version, and patched build inputs when its build succeeds. The command-execution test **still needs to be run inside iSH-AOK on your iPad**, because a standard Linux or QEMU host cannot emulate iSH's syscall behavior.

Source: https://github.com/openai/codex/tree/rust-v0.158.0
Issue: https://github.com/openai/codex/issues/40454
