# Rebuild Codex for iSH-AOK

This source snapshot is based on OpenAI Codex `rust-v0.158.0`, commit `064c6b8c737f5b41d171fdda80bd9ef10ad06eb3`, with the iSH process patches in `codex-rs/utils/pty/src/process_group.rs` and vendored Tokio 1.52.3. `Cargo.toml` and `Cargo.lock` select the patched Tokio.

On Ubuntu 24.04 x86_64 install Rust 1.95.0 with `aarch64-unknown-linux-musl`, Zig 0.14.0, Perl, make, CMake, pkg-config, and clang. Run `./scripts/build-ish-aarch64.sh`. The script verifies the OpenAI V8 archive using its committed checksum, builds ARM64 musl OpenSSL, and outputs `dist/codex-ish-aarch64.tar.gz`. The small repository kit's `.github/workflows/build.yml` fetches this pinned upstream source, applies the patch overlay, and runs the build in GitHub Actions.

No credentials are embedded. The packaged binary requires the unsandboxed flags documented in `README-ish.md` because iSH lacks the needed Linux sandbox features.
